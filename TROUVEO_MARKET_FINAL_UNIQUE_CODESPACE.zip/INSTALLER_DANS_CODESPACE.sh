#!/usr/bin/env bash
set -euo pipefail

ROOT="$(pwd)"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="$ROOT/.backup-trouveo-$STAMP"

echo "1/6 Sauvegarde de la version actuelle..."
mkdir -p "$BACKUP"
for f in index.html app.js style.css manifest.json merci.html sitemap.xml _redirects netlify.toml robots.txt; do
  [ -e "$ROOT/$f" ] && cp -a "$ROOT/$f" "$BACKUP/"
done
[ -d "$ROOT/assets" ] && cp -a "$ROOT/assets" "$BACKUP/"

echo "2/6 Installation des fichiers Trouvéo..."
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
for f in index.html app.js style.css manifest.json merci.html sitemap.xml _redirects netlify.toml; do
  cp -f "$SCRIPT_DIR/$f" "$ROOT/$f"
done
rm -rf "$ROOT/assets"
cp -a "$SCRIPT_DIR/assets" "$ROOT/assets"

echo "3/6 Vérifications..."
test -s "$ROOT/index.html"
test -s "$ROOT/app.js"
test -s "$ROOT/style.css"
test -s "$ROOT/assets/qr-trouveo-market.png"
grep -q 'trouveo-market.netlify.app' "$ROOT/index.html"
grep -q 'type: affiliate ? "product"' "$ROOT/app.js"
grep -q 'function isAffiliateUrl' "$ROOT/app.js"

echo "4/6 Contrôle Git..."
git status --short

echo "5/6 Enregistrement..."
git add index.html app.js style.css manifest.json merci.html sitemap.xml _redirects netlify.toml assets
if git diff --cached --quiet; then
  echo "Aucun changement à enregistrer."
else
  git commit -m "Finalise Trouvéo Market : boutique affiliée, classement et connexions"
fi

echo "6/6 Envoi vers GitHub..."
git push origin HEAD

echo
echo "TERMINÉ."
echo "Sauvegarde locale : $BACKUP"
echo "Netlify doit maintenant déployer automatiquement depuis GitHub."
