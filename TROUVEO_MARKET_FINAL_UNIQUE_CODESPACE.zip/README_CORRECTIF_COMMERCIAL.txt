CORRECTIF COMMERCIAL — FORMULAIRE / PAGE INTROUVABLE

Ce ZIP corrige la partie commerciale qui renvoyait sur une page introuvable.

Changements :
1. Les formulaires renvoient vers l'accueil au lieu de /merci.html.
2. Ajout du fichier _redirects exact pour Netlify.
3. Ajout du fichier netlify.toml pour renforcer les redirections.
4. Conservation du formulaire Netlify Forms.
5. Conservation du QR code officiel.

Après redéploiement :
- ouvrir https://trouveo-market.netlify.app/
- Ctrl + F5
- onglet Commerçant
- envoyer une demande test
- vérifier Netlify > Forms

Ne pas utiliser "Ajouter aussi en test local" pour tester Netlify Forms.
